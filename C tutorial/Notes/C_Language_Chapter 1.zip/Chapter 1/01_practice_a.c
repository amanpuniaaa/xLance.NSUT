#include<stdio.h>

int main(){
    int length=3, breadth=8;
    int area = length*breadth;
    printf("The area of this rectangle is %d", area);
    return 0;
}