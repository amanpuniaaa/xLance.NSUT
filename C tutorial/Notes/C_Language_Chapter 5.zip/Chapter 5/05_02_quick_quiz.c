#include<stdio.h>
void goodMorning();
void goodAfternoon();
void goodNight();

int main(){
    goodMorning();
    goodAfternoon();
    goodNight();
    return 0;
}

void goodMorning(){
    printf("Good Morning Harry\n");
}

void goodAfternoon(){
    printf("Good Afternoon Harry\n");
}

void goodNight(){
    printf("Good Night Harry\n");
}