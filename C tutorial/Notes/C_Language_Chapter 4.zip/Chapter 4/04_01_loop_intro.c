#include<stdio.h>

int main(){
    printf("Hello ");
    printf("world\n");
    int a = 1;
    // Loops are used to repeat similar part of a code snippet efficiently
    // (
    // printf("%d\n", a);
    // a++;) =---> 100 times
     
    return 0;
}